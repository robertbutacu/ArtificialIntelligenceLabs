package com.chess;

import com.chess.game.Board;
import com.chess.game.GameManager;

public class Main {

    public static void main(String[] args) {

        GameManager gm = new GameManager();

        gm.play();
    }
}
